def enlarge(n):
    return int(n) * 100

if __name__ == "__main__":
    pass

x = 5
print(enlarge(x))

z = input("please choose a number to enlarge: ")
print(enlarge(int(z)))