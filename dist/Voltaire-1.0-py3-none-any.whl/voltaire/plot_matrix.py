import numpy as np

def confusion_matrix(y_true, y_pred):
  ''' Compute a confusion matrix using numpy for two np.arrays
  true and pred.

  Result is identical to: 
    "from sklearn.metrics import confusion_matrix" '''

  X = len(np.unique(y_true)) # Number of classes 
  result = np.zeros((X, X))

  for i in range(len(y_true)):
    result[y_true[i]][y_pred[i]] += 1

  return result